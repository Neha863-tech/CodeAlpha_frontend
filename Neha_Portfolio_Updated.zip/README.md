# Neha Kumari — Portfolio

Personal portfolio for Neha Kumari, Dual Degree B.Tech + M.Tech CSE student at NIT Patna.

## Tech Stack
- HTML5
- CSS3
- Vanilla JavaScript
- Google Fonts (Fraunces, Inter, JetBrains Mono)

## Social Links
- GitHub: https://github.com/Neha863-tech/CodeAlpha_frontend
- LinkedIn: https://www.linkedin.com/in/neha-kumari-b23144326

## Local Development
Run from this folder:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Resume
Place your resume at `assets/resume/resume.pdf` for the resume buttons to work.
